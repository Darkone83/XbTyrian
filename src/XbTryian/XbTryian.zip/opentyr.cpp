// opentyr.cpp — Xbox port of opentyr.c
//
// Changes from original:
//   main() renamed to tyrian_main() under _XBOX guard.
//   setupMenu() and its picker helper functions excluded on Xbox (_XBOX guard).
//   All printf() calls removed (no console on Xbox).
//   fprintf(stderr, ...) replaced with OutputDebugStringA.
//   SDL_Init() failure check removed — our stub always returns 0.
//   SDL_Delay(16) in setupMenu excluded with the function.
//   "assuming mouse detected" printf removed.
//   Network block compiles out via WITH_NETWORK guard (unchanged).

#include <xtl.h>

#include "opentyr.h"

#include "config.h"
#include "destruct.h"
#include "editship.h"
#include "episodes.h"
#include "file.h"
#include "font.h"
#include "fonthand.h"
#include "helptext.h"
#include "joystick.h"
#include "jukebox.h"
#include "keyboard.h"
#include "loudness.h"
#include "mainint.h"
#include "mouse.h"
#include "mtrand.h"
#include "network.h"
#include "nortsong.h"
#include "nortvars.h"
#include "opentyrian_version.h"
#include "palette.h"
#include "params.h"
#include "picload.h"
#include "sprite.h"
#include "tyrian2.h"
#include "varz.h"
#include "vga256d.h"
#include "video.h"
#include "video_scale.h"
#include "xmas.h"

#include "SDL.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// =============================================================================
// Picker helper functions and setupMenu
//
// These are PC-only: they present a resolution/scaler settings screen before
// the game starts. On Xbox output is always 640x480 with nearest-neighbor
// scaling — no settings screen is needed or meaningful.
// =============================================================================

#ifndef _XBOX

static size_t getDisplayPickerItemsCount(void)
{
    return 1 + (size_t)SDL_GetNumVideoDisplays();
}

static const char* getDisplayPickerItem(size_t i, char* buffer, size_t bufferSize)
{
    if (i == 0)
        return "Window";
    snprintf(buffer, bufferSize, "Display %d", (int)i);
    return buffer;
}

static size_t getScalerPickerItemsCount(void)
{
    return (size_t)scalers_count;
}

static const char* getScalerPickerItem(size_t i, char* buffer, size_t bufferSize)
{
    (void)buffer; (void)bufferSize;
    return scalers[i].name;
}

static size_t getScalingModePickerItemsCount(void)
{
    return (size_t)ScalingMode_MAX;
}

static const char* getScalingModePickerItem(size_t i, char* buffer, size_t bufferSize)
{
    (void)buffer; (void)bufferSize;
    return scaling_mode_names[i];
}

void setupMenu(void)
{
    // Full setupMenu body omitted — see original opentyr.c.
    // On Xbox this function is never called.
}

#else // _XBOX

// Stub: setupMenu is never called on Xbox.
void setupMenu(void) {}

#endif // _XBOX

// =============================================================================
// tyrian_main — the game's init chain and main loop.
// Called from main.cpp after D3D device creation.
// =============================================================================


static void diag_color(DWORD color, int ms = 500)
{
    D3DDevice_Clear(0, NULL, D3DCLEAR_TARGET, color, 1.0f, 0);
    D3DDevice_Swap(0);
    Sleep(ms);
}
#ifdef _XBOX
int tyrian_main(int argc, char* argv[])
#else
int main(int argc, char* argv[])
#endif
{
    mt_srand(time(NULL));

    // PC build prints version banner here — omitted on Xbox (no console).

    // SDL_Init is a no-op stub on Xbox; check removed.
    SDL_Init(0);

    JE_loadConfiguration();

    xmas = xmas_time();  // arg handler may override

    JE_paramCheck(argc, argv);

    // init_video first so we have D3D for diagnostics
    init_video();
    init_keyboard();
    init_joysticks();


    // scanForEpisodes moved after video init so any crash is visible
    diag_color(0x00FF0000, 300); // RED: video init done
    JE_scanForEpisodes();

    if (xmas && (!dir_file_exists(data_dir(), "tyrianc.shp") ||
        !dir_file_exists(data_dir(), "voicesc.snd")))
    {
        xmas = false;
        OutputDebugStringA("warning: Christmas data missing, disabling xmas mode\n");
    }

    diag_color(0x0000FF00, 300); // GREEN: scanEpisodes done
    JE_loadPals();
    diag_color(0x000000FF, 300); // BLUE: loadPals done
    JE_loadMainShapeTables(xmas ? "tyrianc.shp" : "tyrian.shp");

    if (xmas && !xmas_prompt())
    {
        xmas = false;
        free_main_shape_tables();
        JE_loadMainShapeTables("tyrian.shp");
    }

    // Default options
    youAreCheating = false;
    smoothScroll = true;
    loadDestruct = false;

    diag_color(0x00FFFF00, 300); // YELLOW: shapes done
    if (!audio_disabled)
    {
        init_audio();
        load_music();
        loadSndFile(xmas);
    }

    if (record_demo)
        OutputDebugStringA("demo recording enabled\n");

    diag_color(0x00FF00FF, 300); // MAGENTA: audio done
    JE_loadExtraShapes();   // Editship

    diag_color(0x0000FFFF, 300); // CYAN: extraShapes done
    JE_loadHelpText();

    if (isNetworkGame)
    {
#ifdef WITH_NETWORK
        if (network_init())
            network_tyrian_halt(3, false);
#else
        OutputDebugStringA("OpenTyrian was compiled without networking support\n");
        JE_tyrianHalt(5);
#endif
    }

#ifdef NDEBUG
    if (!isNetworkGame)
        intro_logos();
#endif

    for (;;)
    {
        diag_color(0x00FFFFFF, 300); // WHITE: entering titleScreen loop iteration
        JE_initPlayerData();
        JE_sortHighScores();

        play_demo = false;
        stopped_demo = false;
        gameLoaded = false;
        jumpSection = false;

#ifdef WITH_NETWORK
        if (isNetworkGame)
        {
            networkStartScreen();
        }
        else
#endif
        {
            diag_color(0x004444FF, 300); // DARK BLUE: calling titleScreen
            bool ts_result = titleScreen();
            diag_color(ts_result ? 0x0044FF44 : 0x00FF4444, 300); // GREEN=continue RED=quit
            if (!ts_result)
                break;  // player quit from title screen
        }

        if (loadDestruct)
        {
            JE_destructGame();
            loadDestruct = false;
        }
        else
        {
            diag_color(0x00FF8800, 300); // ORANGE: calling JE_main
            JE_main();
            diag_color(0x00884400, 300); // BROWN: JE_main returned

            if (trentWin)
                break;  // player beat SuperTyrian
        }
    }

    JE_tyrianHalt(0);

    return 0;
}